{
    'name': 'Hotel Management',
    'version': '1.0',
    'category': 'Hotel Management',
    'summary': 'Module de gestion immobilière pour les hôtels',
    'depends': ['base'],
    'data': [
        'security/security.xml',  # Doit être chargé en premier pour définir les groupes
        'security/ir.model.access.csv',
        'views/building_views.xml',
        'views/room_views.xml',
        'views/customer_views.xml',
        'views/reservation_views.xml',
        'views/payment_views.xml',
        'views/invoice_views.xml',
        'views/space_views.xml',
        'views/staff_views.xml',
        'views/planning_views.xml',
    ],
    'application': True,
}
