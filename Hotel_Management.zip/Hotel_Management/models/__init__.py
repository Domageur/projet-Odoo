# hotel_management/models/__init__.py
from . import building
from . import room
from . import customer
from . import reservation
from . import payment
from . import invoice
from . import space
from . import staff
from . import planning
