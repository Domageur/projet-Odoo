# hotel_management/models/building.py
from odoo import models, fields

class HotelBuilding(models.Model):
    _name = 'hotel.building'
    _description = 'Hotel Building'

    name = fields.Char(string='Name', required=True)
    address = fields.Char(string='Address')
    manager_id = fields.Many2one('res.users', string='Manager')
