# hotel_management/models/invoice.py
from odoo import models, fields

class HotelInvoice(models.Model):
    _name = 'hotel.invoice'
    _description = 'Hotel Invoice'

    reservation_id = fields.Many2one('hotel.reservation', string='Reservation', required=True)
    invoice_date = fields.Date(string='Invoice Date', required=True)
    amount = fields.Float(string='Amount', required=True)
    status = fields.Selection([('paid', 'Paid'), ('unpaid', 'Unpaid')], string='Status', default='unpaid')
