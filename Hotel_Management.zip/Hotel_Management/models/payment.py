# hotel_management/models/payment.py
from odoo import models, fields

class HotelPayment(models.Model):
    _name = 'hotel.payment'
    _description = 'Hotel Payment'

    reservation_id = fields.Many2one('hotel.reservation', string='Reservation', required=True)
    amount = fields.Float(string='Amount', required=True)
    payment_date = fields.Date(string='Payment Date', required=True)
    payment_method = fields.Selection([('cash', 'Cash'), ('credit_card', 'Credit Card'), ('bank_transfer', 'Bank Transfer')], string='Payment Method', required=True)
