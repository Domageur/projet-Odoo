# hotel_management/models/planning.py
from odoo import models, fields

class HotelPlanning(models.Model):
    _name = 'hotel.planning'
    _description = 'Hotel Planning'

    name = fields.Char(string='Task', required=True)
    staff_id = fields.Many2one('hotel.staff', string='Staff', required=True)
    start_date = fields.Datetime(string='Start Date', required=True)
    end_date = fields.Datetime(string='End Date', required=True)
