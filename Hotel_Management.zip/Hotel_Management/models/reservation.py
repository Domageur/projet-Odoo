# hotel_management/models/reservation.py
from odoo import models, fields

class HotelReservation(models.Model):
    _name = 'hotel.reservation'
    _description = 'Hotel Reservation'

    customer_id = fields.Many2one('hotel.customer', string='Customer', required=True)
    room_id = fields.Many2one('hotel.room', string='Room', required=True)
    checkin_date = fields.Date(string='Check-In Date', required=True)
    checkout_date = fields.Date(string='Check-Out Date', required=True)
