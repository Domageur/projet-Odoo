# hotel_management/models/room.py
from odoo import models, fields

class HotelRoom(models.Model):
    _name = 'hotel.room'
    _description = 'Hotel Room'

    name = fields.Char(string='Room Number', required=True)
    building_id = fields.Many2one('hotel.building', string='Building', required=True)
    room_type = fields.Selection([('single', 'Single'), ('double', 'Double'), ('suite', 'Suite')], string='Room Type', required=True)
    status = fields.Selection([('available', 'Available'), ('occupied', 'Occupied'), ('maintenance', 'Maintenance')], string='Status', default='available')
