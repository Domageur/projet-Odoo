# hotel_management/models/space.py
from odoo import models, fields

class HotelSpace(models.Model):
    _name = 'hotel.space'
    _description = 'Hotel Space'

    name = fields.Char(string='Name', required=True)
    building_id = fields.Many2one('hotel.building', string='Building', required=True)
    space_type = fields.Selection([('conference', 'Conference Room'), ('banquet', 'Banquet Hall'), ('gym', 'Gym')], string='Space Type', required=True)
    status = fields.Selection([('available', 'Available'), ('booked', 'Booked'), ('maintenance', 'Maintenance')], string='Status', default='available')
