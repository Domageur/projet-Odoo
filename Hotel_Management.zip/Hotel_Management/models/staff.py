# hotel_management/models/staff.py
from odoo import models, fields

class HotelStaff(models.Model):
    _name = 'hotel.staff'
    _description = 'Hotel Staff'

    name = fields.Char(string='Name', required=True)
    job_position = fields.Selection([('manager', 'Manager'), ('receptionist', 'Receptionist'), ('housekeeper', 'Housekeeper'), ('cook', 'Cook')], string='Job Position', required=True)
    building_id = fields.Many2one('hotel.building', string='Building', required=True)
